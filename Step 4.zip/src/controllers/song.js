import * as songServices from '../services/songs';
/**
 * @description songMastered controller.
 * @param {object} req Request object
 * @param {object} res Response object
 * @returns {object} The song info
 */

export const songMastered = async (req, res) => {
  try {
    const song = await songServices.songMastered(req.body);
    res.status(200).json({
      success: true,
      message: 'Mastered song saved successfully',
      result: song,
    });
  } catch (error) {
    res.status(error.httpCode).json({ success: false, message: error.message });
  }
};

export const getSong = async (req, res) => {
  try {
    const song = await songServices.getSong(req.params);
    res.status(200).json({
      success: true,
      message: 'Song retrieved successfully',
      result: song,
    });
  } catch (error) {
    res.status(error.httpCode).json({ success: false, message: error.message });
  }
};

export const getPlayingStreak = async (req, res) => {
  try {
    const song = await songServices.getPlayingStreak(req.params);
    res.status(200).json({
      success: true,
      message: 'Song retrieved successfully',
      result: song,
    });
  } catch (error) {
    res.status(error.httpCode).json({ success: false, message: error.message });
  }
};
