/* eslint-disable no-unused-vars */
import express from 'express';
import { songMastered, getSong, getPlayingStreak } from '../controllers';
import validateBody from '../middleware/validateBody';

const router = express.Router();
router
  .route('/song/:songId')
  .get(
    getSong,
  );
router
  .route('/song/:songId/playing-streak')
  .get(
    getPlayingStreak,
  );
router
  .route('/song-mastered')
  .post(
    validateBody('songSchema', 'songMastered'),
    songMastered,
  );

export default router;
