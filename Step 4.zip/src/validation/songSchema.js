import Joi from '@hapi/joi';

// Schema to validate post inputs.
export const songMastered = Joi.object({
  songId: Joi.string().required(),
  latitude: Joi.string().required(),
  longitude: Joi.string().required(),
});

export const getSong = Joi.object({
  songId: Joi.string().required(),
});
