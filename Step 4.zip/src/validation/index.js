import * as songSchema from './songSchema';

export {
  songSchema,
};
