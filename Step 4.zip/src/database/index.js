import setup from './setup';

setup();
