import mongoose from 'mongoose';

const { Schema } = mongoose;

const masteredSongsSchema = new Schema({
  songId: { type: String },
  location: {
    latitude: { type: String },
    longitude: { type: String },
  },
  userId: { type: String, required: true },
}, { timestamps: true });

export default mongoose.model('mastered-songs', masteredSongsSchema);
