import mongoose from 'mongoose';

const { Schema } = mongoose;

const songSchema = new Schema({
  name: { type: String },
  genre: { type: String },
  description: { type: String },
  artist: { type: String },
  lyrics: { type: String },
}, { timestamps: true });

export default mongoose.model('song', songSchema);
