import axios from 'axios';
import dotenv from 'dotenv';
import MasteredSongModel from '../database/masteredSongModel';
import songModel from '../database/songModel';
import { log } from '../utils/logger';
import { InternalServerError } from '../utils/errors';

dotenv.config();

export const songMastered = async (payload) => {
  const { songId, latitude, longitude, userId } = payload;
  try {
    log.info(`Saving mastered song with id ${songId}: userId: ${userId}`);
    const song = await new MasteredSongModel({
      songId,
      location: {
        latitude,
        longitude,
      },
      userId: userId || 'asdf-2643-sdsa-4ad3', // Default userId
    }).save();
    return song;
  } catch (error) {
    log.info(`An error occured. error: ${error}`);
    throw new InternalServerError('Unable to save song. Try again later');
  }
};

export const getSong = async (payload) => {
  const apiKey = process.env.OPEN_WEATHER_API_KEY;
  const weathers = [];

  const promises = [];

  const { songId } = payload;
  const song = await songModel.findById(songId);
  const mastered = await MasteredSongModel.aggregate([
    { $unwind: '$location' },
    { $match: { songId } },
    { $limit: 3 },
  ]);
  if (!mastered) {
    return song;
  }
  const arr = mastered;

  for (let i = 0; i < arr.length; i += 1) {
    promises.push(
      axios.get(`https://api.openweathermap.org/data/2.5/onecall/timemachine?lat=${arr[i].location.latitude}&lon=${arr[i].location.longitude}&dt=${Math.floor(new Date(arr[i].createdAt).getTime() / 1000.0)}&appid=${apiKey}`)
        .then((res) => {
          weathers.push(res.data);
        })
        .catch((err) => {
          log.error(`An error occured: ${err}`);
        })
        .finally(() => {
          // Do somtthing
        }),
    );
  }

  return Promise.all(promises).then(() => ({
    ...song._doc,
    bestWeathers: weathers,
  }));
};

export const getStreak = async (payload) => {
  // Might take a while to design the Schema and implement.
  // If the weather condition changes or another song is learnt the streak ends.
};
